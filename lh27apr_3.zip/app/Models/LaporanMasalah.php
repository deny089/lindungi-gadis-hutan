<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class LaporanMasalah extends Model {

	protected $guarded = array();
	protected $table = 'laporan_masalah';
	public $timestamps = false;
	
	
	
	
}