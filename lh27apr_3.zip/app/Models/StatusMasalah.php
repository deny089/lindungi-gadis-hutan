<?php namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class StatusMasalah extends Model {

	protected $guarded = array();
	protected $table = 'status_laporan_masalah';
	public $timestamps = false;
	
	
	
	
}